import React, { useState, useMemo } from 'react';
import {
  Plus,
  Search,
  MessageSquare,
  Pin,
  Trash2,
  Edit2,
  Download,
  Settings,
  Sun,
  Moon,
  Laptop,
  GraduationCap,
  Sparkles,
  Wifi,
  WifiOff,
  X,
  Check,
} from 'lucide-react';
import { Conversation, ThemeMode } from '../types';
import { exportConversationAsMarkdown } from '../utils/storage';
import { PWAInstallButton } from './PWAInstallButton';

interface SidebarProps {
  conversations: Conversation[];
  currentConversationId: string | null;
  onSelectConversation: (id: string) => void;
  onNewChat: () => void;
  onDeleteConversation: (id: string) => void;
  onRenameConversation: (id: string, newTitle: string) => void;
  onTogglePin: (id: string) => void;
  isOpen: boolean;
  onClose: () => void;
  onOpenSettings: () => void;
  isOnline: boolean;
  theme: ThemeMode;
  onToggleTheme: () => void;
  assistantName: string;
}

export const Sidebar: React.FC<SidebarProps> = ({
  conversations,
  currentConversationId,
  onSelectConversation,
  onNewChat,
  onDeleteConversation,
  onRenameConversation,
  onTogglePin,
  isOpen,
  onClose,
  onOpenSettings,
  isOnline,
  theme,
  onToggleTheme,
  assistantName,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingTitle, setEditingTitle] = useState('');

  // Filter conversations
  const filteredConversations = useMemo(() => {
    if (!searchQuery.trim()) return conversations;
    const q = searchQuery.toLowerCase();
    return conversations.filter(
      (c) =>
        c.title.toLowerCase().includes(q) ||
        c.messages.some((m) => m.content.toLowerCase().includes(q))
    );
  }, [conversations, searchQuery]);

  // Group conversations by timeframe
  const grouped = useMemo(() => {
    const pinned: Conversation[] = [];
    const today: Conversation[] = [];
    const yesterday: Conversation[] = [];
    const last7Days: Conversation[] = [];
    const older: Conversation[] = [];

    const now = new Date();
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    const startOfYesterday = startOfToday - 86400000;
    const startOf7Days = startOfToday - 7 * 86400000;

    filteredConversations.forEach((c) => {
      if (c.pinned) {
        pinned.push(c);
        return;
      }
      const time = c.updatedAt || c.createdAt;
      if (time >= startOfToday) {
        today.push(c);
      } else if (time >= startOfYesterday) {
        yesterday.push(c);
      } else if (time >= startOf7Days) {
        last7Days.push(c);
      } else {
        older.push(c);
      }
    });

    return { pinned, today, yesterday, last7Days, older };
  }, [filteredConversations]);

  const startEditing = (c: Conversation, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingId(c.id);
    setEditingTitle(c.title);
  };

  const saveEditing = (id: string, e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (editingTitle.trim()) {
      onRenameConversation(id, editingTitle.trim());
    }
    setEditingId(null);
  };

  const handleExport = (c: Conversation, e: React.MouseEvent) => {
    e.stopPropagation();
    const markdown = exportConversationAsMarkdown(c);
    const blob = new Blob([markdown], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${c.title.replace(/[^a-z0-9]/gi, '_').toLowerCase() || 'chat'}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const renderGroup = (title: string, list: Conversation[]) => {
    if (list.length === 0) return null;

    return (
      <div className="mb-4">
        <div className="px-3 mb-1.5 text-[11px] font-semibold uppercase tracking-wider text-zinc-400 dark:text-zinc-500">
          {title}
        </div>
        <div className="space-y-0.5">
          {list.map((c) => {
            const isActive = c.id === currentConversationId;
            const isEditing = editingId === c.id;

            return (
              <div
                key={c.id}
                onClick={() => {
                  onSelectConversation(c.id);
                  if (window.innerWidth < 768) onClose();
                }}
                className={`group relative flex items-center justify-between px-3 py-2.5 rounded-xl cursor-pointer text-sm transition-all ${
                  isActive
                    ? 'bg-indigo-50 text-indigo-950 font-medium dark:bg-indigo-950/60 dark:text-indigo-100'
                    : 'text-zinc-700 hover:bg-zinc-100/80 dark:text-zinc-300 dark:hover:bg-zinc-800/60'
                }`}
              >
                <div className="flex items-center gap-2.5 min-w-0 flex-1">
                  {c.pinned ? (
                    <Pin className="w-4 h-4 text-amber-500 shrink-0 fill-amber-500" />
                  ) : (
                    <MessageSquare className="w-4 h-4 text-zinc-400 shrink-0 group-hover:text-zinc-600 dark:text-zinc-500 dark:group-hover:text-zinc-300" />
                  )}

                  {isEditing ? (
                    <form
                      onSubmit={(e) => saveEditing(c.id, e)}
                      onClick={(e) => e.stopPropagation()}
                      className="flex items-center gap-1 flex-1"
                    >
                      <input
                        type="text"
                        value={editingTitle}
                        onChange={(e) => setEditingTitle(e.target.value)}
                        autoFocus
                        onBlur={() => saveEditing(c.id)}
                        className="w-full text-xs py-0.5 px-1.5 rounded bg-white dark:bg-zinc-900 border border-indigo-400 dark:border-indigo-500 focus:outline-none"
                      />
                      <button
                        type="submit"
                        className="p-1 hover:text-emerald-500 text-zinc-400"
                        title="Save"
                      >
                        <Check className="w-3.5 h-3.5" />
                      </button>
                    </form>
                  ) : (
                    <span className="truncate text-[13.5px]" title={c.title}>
                      {c.title}
                    </span>
                  )}
                </div>

                {!isEditing && (
                  <div className="hidden group-hover:flex items-center gap-0.5 ml-1 shrink-0">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onTogglePin(c.id);
                      }}
                      title={c.pinned ? 'Unpin chat' : 'Pin chat'}
                      className="p-1 rounded hover:bg-zinc-200/80 dark:hover:bg-zinc-700 text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200"
                    >
                      <Pin className={`w-3.5 h-3.5 ${c.pinned ? 'fill-current text-amber-500' : ''}`} />
                    </button>
                    <button
                      onClick={(e) => startEditing(c, e)}
                      title="Rename"
                      className="p-1 rounded hover:bg-zinc-200/80 dark:hover:bg-zinc-700 text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={(e) => handleExport(c, e)}
                      title="Export as Markdown"
                      className="p-1 rounded hover:bg-zinc-200/80 dark:hover:bg-zinc-700 text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200"
                    >
                      <Download className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        if (confirm(`Delete "${c.title}"?`)) {
                          onDeleteConversation(c.id);
                        }
                      }}
                      title="Delete"
                      className="p-1 rounded hover:bg-red-100 dark:hover:bg-red-950/60 text-zinc-400 hover:text-red-600 dark:hover:text-red-400"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div
          onClick={onClose}
          className="fixed inset-0 z-40 bg-black/40 backdrop-blur-xs md:hidden"
        />
      )}

      <aside
        className={`fixed md:static inset-y-0 left-0 z-50 flex flex-col w-72 md:w-80 bg-zinc-50 dark:bg-zinc-900 border-r border-zinc-200 dark:border-zinc-800 transition-transform duration-200 ease-in-out shrink-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
        }`}
      >
        {/* Brand header */}
        <div className="flex items-center justify-between p-4 border-b border-zinc-200/80 dark:border-zinc-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-600 via-violet-600 to-indigo-400 flex items-center justify-center text-white shadow-md shadow-indigo-500/20">
              <GraduationCap className="w-5 h-5" />
            </div>
            <div>
              <h1 className="font-bold text-[15px] tracking-tight text-zinc-900 dark:text-white flex items-center gap-1.5">
                {assistantName}
                <Sparkles className="w-3.5 h-3.5 text-indigo-500 fill-indigo-500" />
              </h1>
              <p className="text-[11px] text-zinc-500 dark:text-zinc-400">AI Study Assistant</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="md:hidden p-1.5 rounded-lg text-zinc-400 hover:text-zinc-600 hover:bg-zinc-200 dark:hover:bg-zinc-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* New Chat Button */}
        <div className="p-3 pb-1">
          <button
            onClick={() => {
              onNewChat();
              if (window.innerWidth < 768) onClose();
            }}
            className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl font-medium text-sm text-white bg-indigo-600 hover:bg-indigo-700 active:scale-[0.98] transition-all shadow-sm shadow-indigo-600/30"
          >
            <Plus className="w-4 h-4" />
            <span>New Chat</span>
          </button>
        </div>

        {/* PWA Install Button in Sidebar */}
        <div className="px-3 pb-2">
          <PWAInstallButton />
        </div>

        {/* Search input */}
        <div className="px-3 pb-2">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" />
            <input
              type="text"
              placeholder="Search previous chats..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs rounded-lg bg-zinc-200/60 dark:bg-zinc-800/70 text-zinc-800 dark:text-zinc-200 placeholder-zinc-400 focus:outline-none focus:ring-1 focus:ring-indigo-500 transition-colors"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Conversation list */}
        <div className="flex-1 overflow-y-auto px-2 py-1">
          {conversations.length === 0 ? (
            <div className="text-center py-10 px-4 text-xs text-zinc-400 dark:text-zinc-500">
              <MessageSquare className="w-8 h-8 mx-auto mb-2 opacity-40" />
              No conversations yet. Start a new chat to begin studying!
            </div>
          ) : filteredConversations.length === 0 ? (
            <div className="text-center py-8 px-4 text-xs text-zinc-400 dark:text-zinc-500">
              No chats found matching "{searchQuery}".
            </div>
          ) : (
            <>
              {renderGroup('Pinned', grouped.pinned)}
              {renderGroup('Today', grouped.today)}
              {renderGroup('Yesterday', grouped.yesterday)}
              {renderGroup('Previous 7 Days', grouped.last7Days)}
              {renderGroup('Older', grouped.older)}
            </>
          )}
        </div>

        {/* Offline status notice */}
        <div className="px-3 py-2 border-t border-zinc-200/80 dark:border-zinc-800/80 bg-zinc-100/50 dark:bg-zinc-900/50">
          <div className="flex items-center justify-between text-[11px] text-zinc-500 dark:text-zinc-400">
            <span className="flex items-center gap-1.5 font-medium">
              {isOnline ? (
                <>
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  <Wifi className="w-3.5 h-3.5 text-emerald-500" />
                  <span>Online & Ready</span>
                </>
              ) : (
                <>
                  <span className="w-2 h-2 rounded-full bg-amber-500" />
                  <WifiOff className="w-3.5 h-3.5 text-amber-500" />
                  <span>Offline (Saved Chats Readable)</span>
                </>
              )}
            </span>
            <span>{conversations.length} saved</span>
          </div>
        </div>

        {/* Bottom bar: Theme and Settings */}
        <div className="p-3 border-t border-zinc-200/80 dark:border-zinc-800 flex items-center justify-between">
          <button
            onClick={onToggleTheme}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white hover:bg-zinc-200/60 dark:hover:bg-zinc-800 transition-colors"
            title="Toggle theme"
          >
            {theme === 'dark' ? (
              <>
                <Moon className="w-4 h-4 text-indigo-400" />
                <span>Dark</span>
              </>
            ) : theme === 'light' ? (
              <>
                <Sun className="w-4 h-4 text-amber-500" />
                <span>Light</span>
              </>
            ) : (
              <>
                <Laptop className="w-4 h-4 text-zinc-400" />
                <span>System</span>
              </>
            )}
          </button>

          <button
            onClick={onOpenSettings}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white hover:bg-zinc-200/60 dark:hover:bg-zinc-800 transition-colors"
          >
            <Settings className="w-4 h-4" />
            <span>Settings</span>
          </button>
        </div>
      </aside>
    </>
  );
};
