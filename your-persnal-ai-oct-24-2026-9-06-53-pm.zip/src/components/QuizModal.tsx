import React, { useState } from 'react';
import {
  X,
  Sparkles,
  Award,
  CheckCircle2,
  XCircle,
  HelpCircle,
  RotateCcw,
  Loader2,
} from 'lucide-react';
import { QuizData } from '../types';

interface QuizModalProps {
  isOpen: boolean;
  onClose: () => void;
  topicTitle: string;
  topicContext?: string;
  language: string;
}

export const QuizModal: React.FC<QuizModalProps> = ({
  isOpen,
  onClose,
  topicTitle,
  topicContext,
  language,
}) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [quiz, setQuiz] = useState<QuizData | null>(null);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [showResults, setShowResults] = useState(false);

  // Generate quiz when modal opens if not already loaded
  React.useEffect(() => {
    if (isOpen && !quiz && !loading) {
      handleGenerate();
    }
  }, [isOpen]);

  const handleGenerate = async () => {
    setLoading(true);
    setError(null);
    setSelectedAnswers({});
    setShowResults(false);

    try {
      const res = await fetch('/api/quiz-generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: topicTitle || 'General Study Review',
          context: topicContext?.slice(0, 1500) || '',
          language,
        }),
      });

      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        throw new Error(errJson.error || 'Failed to generate quiz');
      }

      const data = await res.json();
      if (!data.questions || !Array.isArray(data.questions)) {
        throw new Error('Invalid quiz response from assistant');
      }
      setQuiz(data);
    } catch (err: any) {
      setError(err.message || 'Could not load quiz questions.');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  const handleSelect = (qIdx: number, optIdx: number) => {
    if (showResults) return;
    setSelectedAnswers((prev) => ({ ...prev, [qIdx]: optIdx }));
  };

  const calculateScore = () => {
    if (!quiz) return 0;
    return quiz.questions.reduce((score, q, idx) => {
      return score + (selectedAnswers[idx] === q.correctIndex ? 1 : 0);
    }, 0);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs">
      <div className="w-full max-w-xl max-h-[90vh] overflow-y-auto bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl shadow-2xl flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-zinc-200 dark:border-zinc-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-amber-50 dark:bg-amber-950/50 text-amber-600 dark:text-amber-400">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-zinc-900 dark:text-white flex items-center gap-1.5">
                Quick Knowledge Check
                <Sparkles className="w-4 h-4 text-amber-500 fill-amber-500" />
              </h2>
              <p className="text-xs text-zinc-500 dark:text-zinc-400 truncate max-w-sm">
                Topic: {topicTitle || 'Study Review'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-zinc-600 hover:bg-zinc-100 dark:hover:bg-zinc-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 flex-1 space-y-6">
          {loading && (
            <div className="py-12 flex flex-col items-center justify-center text-center space-y-3">
              <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
              <p className="text-sm font-medium text-zinc-700 dark:text-zinc-300">
                Crafting targeted quiz questions for you...
              </p>
              <p className="text-xs text-zinc-400">Testing key comprehension points</p>
            </div>
          )}

          {error && (
            <div className="p-4 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900/60 text-xs text-red-700 dark:text-red-300 space-y-2">
              <p className="font-semibold">Unable to generate quiz:</p>
              <p>{error}</p>
              <button
                onClick={handleGenerate}
                className="mt-2 px-3 py-1.5 rounded-lg bg-red-600 text-white font-medium hover:bg-red-700 transition-colors"
              >
                Try Again
              </button>
            </div>
          )}

          {!loading && quiz && (
            <div className="space-y-6">
              {showResults && (
                <div className="p-4 rounded-xl bg-indigo-50 dark:bg-indigo-950/50 border border-indigo-200 dark:border-indigo-800/80 text-center space-y-1">
                  <div className="text-sm font-semibold text-indigo-900 dark:text-indigo-200">
                    Your Score: {calculateScore()} / {quiz.questions.length}
                  </div>
                  <p className="text-xs text-indigo-700 dark:text-indigo-300">
                    {calculateScore() === quiz.questions.length
                      ? '🎉 Outstanding! You mastered these concepts.'
                      : '👍 Good effort! Review the step-by-step explanations below.'}
                  </p>
                </div>
              )}

              {quiz.questions.map((q, qIdx) => {
                const userChoice = selectedAnswers[qIdx];
                return (
                  <div
                    key={qIdx}
                    className="p-4 rounded-xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50/50 dark:bg-zinc-800/40 space-y-3"
                  >
                    <div className="flex items-start gap-2 text-sm font-semibold text-zinc-900 dark:text-zinc-100">
                      <span className="w-5 h-5 rounded-full bg-indigo-100 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 flex items-center justify-center text-xs shrink-0 mt-0.5 font-bold">
                        {qIdx + 1}
                      </span>
                      <span>{q.question}</span>
                    </div>

                    <div className="space-y-2">
                      {q.options.map((opt, optIdx) => {
                        const isChosen = userChoice === optIdx;
                        const isCorrect = q.correctIndex === optIdx;

                        let style =
                          'border-zinc-200 dark:border-zinc-700/80 hover:border-zinc-300 dark:hover:border-zinc-600 bg-white dark:bg-zinc-800/80 text-zinc-700 dark:text-zinc-300';

                        if (showResults) {
                          if (isCorrect) {
                            style =
                              'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/50 text-emerald-950 dark:text-emerald-200 font-semibold';
                          } else if (isChosen && !isCorrect) {
                            style =
                              'border-red-500 bg-red-50 dark:bg-red-950/50 text-red-950 dark:text-red-200';
                          }
                        } else if (isChosen) {
                          style =
                            'border-indigo-600 bg-indigo-50/80 dark:bg-indigo-950/60 dark:border-indigo-500 text-indigo-950 dark:text-indigo-200 font-medium';
                        }

                        return (
                          <div
                            key={optIdx}
                            onClick={() => handleSelect(qIdx, optIdx)}
                            className={`p-3 rounded-xl border text-xs cursor-pointer flex items-center justify-between transition-all ${style}`}
                          >
                            <span>{opt}</span>
                            {showResults && isCorrect && (
                              <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                            )}
                            {showResults && isChosen && !isCorrect && (
                              <XCircle className="w-4 h-4 text-red-500 shrink-0" />
                            )}
                          </div>
                        );
                      })}
                    </div>

                    {showResults && (
                      <div className="pt-2 text-xs text-zinc-600 dark:text-zinc-400 bg-zinc-100 dark:bg-zinc-900/60 p-3 rounded-lg border border-zinc-200/80 dark:border-zinc-800 flex items-start gap-2">
                        <HelpCircle className="w-4 h-4 text-indigo-500 shrink-0 mt-0.5" />
                        <div>
                          <strong>Explanation: </strong>
                          {q.explanation}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer */}
        {!loading && quiz && (
          <div className="p-4 border-t border-zinc-200 dark:border-zinc-800 flex items-center justify-between bg-zinc-50 dark:bg-zinc-900/80">
            <button
              onClick={handleGenerate}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              New Questions
            </button>

            {!showResults ? (
              <button
                onClick={() => setShowResults(true)}
                disabled={Object.keys(selectedAnswers).length === 0}
                className="px-5 py-2 rounded-xl text-xs font-medium text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-sm shadow-indigo-600/30"
              >
                Submit Answers
              </button>
            ) : (
              <button
                onClick={onClose}
                className="px-5 py-2 rounded-xl text-xs font-medium text-white bg-indigo-600 hover:bg-indigo-700 transition-all"
              >
                Done
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
