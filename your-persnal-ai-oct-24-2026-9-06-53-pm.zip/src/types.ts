export type StudyMode =
  | 'step-by-step'
  | 'socratic'
  | 'exam-prep'
  | 'code-mentor'
  | 'quick-summary'
  | 'language-tutor';

export type DetailLevel = 'detailed' | 'balanced' | 'concise';

export type ThemeMode = 'light' | 'dark' | 'system';

export interface Attachment {
  id: string;
  type: 'image' | 'file';
  name: string;
  mimeType: string;
  size: number;
  data?: string; // base64 for images
  text?: string; // extracted text for documents/notes
}

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
  attachments?: Attachment[];
  isStreaming?: boolean;
  error?: string;
}

export interface Conversation {
  id: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  messages: Message[];
  pinned?: boolean;
  studyMode?: StudyMode;
}

export interface UserSettings {
  assistantName: string;
  language: string;
  studyMode: StudyMode;
  detailLevel: DetailLevel;
  theme: ThemeMode;
  ttsVoiceEnabled: boolean;
}

export interface QuizQuestion {
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface QuizData {
  title: string;
  questions: QuizQuestion[];
}
