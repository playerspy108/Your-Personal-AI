import React, { useState } from 'react';
import {
  X,
  Languages,
  User,
  BookOpen,
  Volume2,
  Trash2,
  Download,
  ShieldCheck,
  Check,
  AlertTriangle,
  Info,
} from 'lucide-react';
import { UserSettings, Conversation } from '../types';
import { AVAILABLE_LANGUAGES, STUDY_MODES, exportAllDataAsJSON } from '../utils/storage';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: UserSettings;
  onSaveSettings: (settings: UserSettings) => void;
  conversations: Conversation[];
  onClearAllHistory: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onSaveSettings,
  conversations,
  onClearAllHistory,
}) => {
  const [formData, setFormData] = useState<UserSettings>(settings);
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveSettings(formData);
    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      onClose();
    }, 600);
  };

  const handleExportAll = () => {
    const jsonStr = exportAllDataAsJSON(conversations, formData);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `your_personal_ai_backup_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs">
      <div className="w-full max-w-xl max-h-[90vh] overflow-y-auto bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl shadow-2xl flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-zinc-200 dark:border-zinc-800">
          <div>
            <h2 className="text-lg font-bold text-zinc-900 dark:text-white">Settings & Preferences</h2>
            <p className="text-xs text-zinc-500 dark:text-zinc-400">
              Customize your assistant's identity, study style, and privacy preferences
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-zinc-600 hover:bg-zinc-100 dark:hover:bg-zinc-800 dark:hover:text-zinc-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6 flex-1">
          {/* Assistant Name */}
          <div className="space-y-2">
            <label className="flex items-center gap-2 text-sm font-semibold text-zinc-800 dark:text-zinc-200">
              <User className="w-4 h-4 text-indigo-500" />
              Assistant Name
            </label>
            <p className="text-xs text-zinc-500 dark:text-zinc-400">
              Choose what name you'd like your study assistant to use (e.g. "Your Personal AI", "Prof. Sophia", "Mentor Alex").
            </p>
            <input
              type="text"
              value={formData.assistantName}
              onChange={(e) => setFormData({ ...formData, assistantName: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-xl border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-800/80 text-sm text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              placeholder="e.g. Your Personal AI"
              required
            />
          </div>

          {/* Preferred Language */}
          <div className="space-y-2">
            <label className="flex items-center gap-2 text-sm font-semibold text-zinc-800 dark:text-zinc-200">
              <Languages className="w-4 h-4 text-indigo-500" />
              Preferred Language
            </label>
            <p className="text-xs text-zinc-500 dark:text-zinc-400">
              Your assistant will answer explanations and breakdowns in this language.
            </p>
            <select
              value={formData.language}
              onChange={(e) => setFormData({ ...formData, language: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-xl border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-800/80 text-sm text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              {AVAILABLE_LANGUAGES.map((lang) => (
                <option key={lang.code} value={lang.code}>
                  {lang.label}
                </option>
              ))}
            </select>
          </div>

          {/* Default Study Mode */}
          <div className="space-y-2">
            <label className="flex items-center gap-2 text-sm font-semibold text-zinc-800 dark:text-zinc-200">
              <BookOpen className="w-4 h-4 text-indigo-500" />
              Default Study Explainer Mode
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {STUDY_MODES.map((mode) => {
                const isSelected = formData.studyMode === mode.id;
                return (
                  <div
                    key={mode.id}
                    onClick={() => setFormData({ ...formData, studyMode: mode.id as any })}
                    className={`p-3 rounded-xl border cursor-pointer transition-all ${
                      isSelected
                        ? 'border-indigo-600 bg-indigo-50/70 dark:bg-indigo-950/40 dark:border-indigo-500 text-indigo-950 dark:text-indigo-100'
                        : 'border-zinc-200 dark:border-zinc-800 hover:border-zinc-300 dark:hover:border-zinc-700 bg-zinc-50/50 dark:bg-zinc-800/40'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-semibold text-xs text-zinc-900 dark:text-zinc-100">
                        {mode.name}
                      </span>
                      {isSelected && <Check className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />}
                    </div>
                    <p className="text-[11px] leading-relaxed text-zinc-500 dark:text-zinc-400">
                      {mode.description}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Detail Level */}
          <div className="space-y-2">
            <label className="text-sm font-semibold text-zinc-800 dark:text-zinc-200">
              Response Depth & Detail
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'detailed', label: 'Detailed Steps', desc: 'Thorough, in-depth breakdown' },
                { id: 'balanced', label: 'Balanced', desc: 'Standard clarity and examples' },
                { id: 'concise', label: 'Concise', desc: 'Quick points & summaries' },
              ].map((opt) => (
                <button
                  type="button"
                  key={opt.id}
                  onClick={() => setFormData({ ...formData, detailLevel: opt.id as any })}
                  className={`p-2.5 rounded-xl border text-center transition-all ${
                    formData.detailLevel === opt.id
                      ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950/50 dark:border-indigo-500 font-semibold text-indigo-950 dark:text-indigo-200'
                      : 'border-zinc-200 dark:border-zinc-800 text-zinc-700 dark:text-zinc-400 hover:border-zinc-300'
                  }`}
                >
                  <div className="text-xs">{opt.label}</div>
                  <div className="text-[10px] text-zinc-500 dark:text-zinc-500">{opt.desc}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Text to speech toggle */}
          <div className="flex items-center justify-between p-3.5 rounded-xl bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-200 dark:border-zinc-800">
            <div className="flex items-center gap-3">
              <Volume2 className="w-5 h-5 text-indigo-500" />
              <div>
                <div className="text-xs font-semibold text-zinc-800 dark:text-zinc-200">
                  Read Aloud (Voice Narration)
                </div>
                <div className="text-[11px] text-zinc-500 dark:text-zinc-400">
                  Enable listen buttons on assistant answers using your device's audio
                </div>
              </div>
            </div>
            <input
              type="checkbox"
              checked={formData.ttsVoiceEnabled}
              onChange={(e) => setFormData({ ...formData, ttsVoiceEnabled: e.target.checked })}
              className="w-4 h-4 rounded text-indigo-600 accent-indigo-600 cursor-pointer"
            />
          </div>

          {/* Privacy & Storage Section */}
          <div className="p-4 rounded-xl bg-zinc-50 dark:bg-zinc-800/40 border border-zinc-200 dark:border-zinc-800 space-y-3">
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-zinc-500 dark:text-zinc-400">
              <ShieldCheck className="w-4 h-4 text-emerald-500" />
              Privacy & Local Storage
            </div>

            <p className="text-xs text-zinc-600 dark:text-zinc-400 leading-relaxed">
              <strong>100% Client-Side Privacy:</strong> Your study chats are stored locally in your browser's private storage. You can read, search, and review all previous chats completely offline without an internet connection.
            </p>

            <div className="flex items-center gap-1.5 text-xs text-zinc-500 dark:text-zinc-400">
              <Info className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
              <span>
                Saved conversations: <strong>{conversations.length}</strong> chats
              </span>
            </div>

            <div className="pt-2 flex flex-wrap gap-2">
              <button
                type="button"
                onClick={handleExportAll}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-zinc-300 dark:border-zinc-700 text-xs font-medium text-zinc-700 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                Export Full Backup (JSON)
              </button>

              {showClearConfirm ? (
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => {
                      onClearAllHistory();
                      setShowClearConfirm(false);
                      onClose();
                    }}
                    className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-red-600 text-white text-xs font-medium hover:bg-red-700 transition-colors"
                  >
                    <AlertTriangle className="w-3.5 h-3.5" />
                    Yes, Delete Everything
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowClearConfirm(false)}
                    className="px-2 py-1.5 text-xs text-zinc-500 hover:text-zinc-700 dark:hover:text-zinc-300"
                  >
                    Cancel
                  </button>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => setShowClearConfirm(true)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-red-200 dark:border-red-900/60 text-xs font-medium text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/40 transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  Clear All Chat History
                </button>
              )}
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-zinc-200 dark:border-zinc-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-medium text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex items-center gap-2 px-5 py-2 rounded-xl text-xs font-medium text-white bg-indigo-600 hover:bg-indigo-700 active:scale-[0.98] transition-all shadow-sm shadow-indigo-600/30"
            >
              {savedSuccess ? (
                <>
                  <Check className="w-4 h-4 text-white" />
                  <span>Saved!</span>
                </>
              ) : (
                <span>Save Changes</span>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
