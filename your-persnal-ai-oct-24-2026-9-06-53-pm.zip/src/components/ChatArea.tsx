import React, { useRef, useEffect, useState } from 'react';
import {
  Menu,
  GraduationCap,
  Sparkles,
  Volume2,
  VolumeX,
  Copy,
  Check,
  RotateCcw,
  Award,
  ChevronDown,
  ArrowDown,
  AlertCircle,
  FileText,
  Calculator,
  Atom,
  Code,
  Globe2,
  BookMarked,
  Share2,
} from 'lucide-react';
import { Conversation, Message, StudyMode, UserSettings } from '../types';
import { MarkdownRenderer } from './MarkdownRenderer';
import { PWAInstallButton } from './PWAInstallButton';
import { STUDY_MODES, exportConversationAsMarkdown } from '../utils/storage';

interface ChatAreaProps {
  conversation: Conversation | null;
  settings: UserSettings;
  onOpenSidebar: () => void;
  onSelectPrompt: (prompt: string) => void;
  onRegenerate: () => void;
  onOpenQuiz: (topic: string, context?: string) => void;
  onUpdateStudyMode: (mode: StudyMode) => void;
  isStreaming: boolean;
  onRenameChat: (title: string) => void;
}

export const ChatArea: React.FC<ChatAreaProps> = ({
  conversation,
  settings,
  onOpenSidebar,
  onSelectPrompt,
  onRegenerate,
  onOpenQuiz,
  onUpdateStudyMode,
  isStreaming,
  onRenameChat,
}) => {
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [speakingId, setSpeakingId] = useState<string | null>(null);
  const [showScrollBottom, setShowScrollBottom] = useState(false);
  const [showModeDropdown, setShowModeDropdown] = useState(false);
  const [isEditingTitle, setIsEditingTitle] = useState(false);
  const [titleInput, setTitleInput] = useState('');

  const messages = conversation?.messages || [];
  const currentStudyMode = conversation?.studyMode || settings.studyMode;

  // Auto-scroll on new messages
  useEffect(() => {
    if (!showScrollBottom) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isStreaming]);

  // Handle scroll detection for scroll-to-bottom button
  const handleScroll = () => {
    if (containerRef.current) {
      const { scrollTop, scrollHeight, clientHeight } = containerRef.current;
      const isNearBottom = scrollHeight - scrollTop - clientHeight < 120;
      setShowScrollBottom(!isNearBottom);
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    setShowScrollBottom(false);
  };

  const handleCopyMessage = async (msg: Message) => {
    try {
      await navigator.clipboard.writeText(msg.content);
      setCopiedId(msg.id);
      setTimeout(() => setCopiedId(null), 2000);
    } catch (err) {
      console.error('Failed to copy text:', err);
    }
  };

  const handleSpeak = (msg: Message) => {
    if (!('speechSynthesis' in window)) {
      alert('Speech synthesis is not supported on this browser.');
      return;
    }

    if (speakingId === msg.id) {
      window.speechSynthesis.cancel();
      setSpeakingId(null);
      return;
    }

    window.speechSynthesis.cancel();
    // Clean markdown symbols for cleaner voice speech
    const cleanText = msg.content
      .replace(/```[\s\S]*?```/g, 'Code block omitted.')
      .replace(/[#*_`]/g, '');

    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.rate = 1.0;
    utterance.onend = () => setSpeakingId(null);
    utterance.onerror = () => setSpeakingId(null);

    setSpeakingId(msg.id);
    window.speechSynthesis.speak(utterance);
  };

  // Pre-built subject cards for new conversations
  const subjectStarters = [
    {
      title: 'Mathematics',
      icon: Calculator,
      color: 'from-blue-500 to-indigo-600',
      prompt: 'Solve quadratic equation 2x² + 5x - 3 = 0 step by step and verify the answer.',
    },
    {
      title: 'Science & Physics',
      icon: Atom,
      color: 'from-emerald-500 to-teal-600',
      prompt: "Explain Newton's three laws of motion with real-world everyday examples.",
    },
    {
      title: 'Coding & Algorithms',
      icon: Code,
      color: 'from-violet-500 to-purple-600',
      prompt: 'Explain how binary search works in Python with code, step-by-step logic, and complexity.',
    },
    {
      title: 'Languages & Grammar',
      icon: Globe2,
      color: 'from-amber-500 to-orange-600',
      prompt: "Explain the difference between 'por' and 'para' in Spanish with sample sentences.",
    },
    {
      title: 'Notes Summarizer',
      icon: BookMarked,
      color: 'from-rose-500 to-pink-600',
      prompt: 'Help me summarize and create an exam study guide with definitions and key formulas.',
    },
    {
      title: 'General Knowledge',
      icon: GraduationCap,
      color: 'from-cyan-500 to-blue-600',
      prompt: 'Explain how the water cycle works step by step for an earth science exam.',
    },
  ];

  const currentModeObj =
    STUDY_MODES.find((m) => m.id === currentStudyMode) || STUDY_MODES[0];

  return (
    <div className="flex-1 flex flex-col h-full bg-white dark:bg-zinc-950 overflow-hidden relative">
      {/* Top Header Bar */}
      <header className="h-14 border-b border-zinc-200/80 dark:border-zinc-800/80 px-4 flex items-center justify-between shrink-0 bg-white/80 dark:bg-zinc-950/80 backdrop-blur-xs z-10">
        <div className="flex items-center gap-3 min-w-0">
          <button
            onClick={onOpenSidebar}
            className="md:hidden p-2 rounded-lg text-zinc-500 hover:text-zinc-700 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800"
            title="Open sidebar"
          >
            <Menu className="w-5 h-5" />
          </button>

          {/* Chat title with inline edit */}
          {conversation ? (
            isEditingTitle ? (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (titleInput.trim()) onRenameChat(titleInput.trim());
                  setIsEditingTitle(false);
                }}
                className="flex items-center gap-1.5"
              >
                <input
                  type="text"
                  value={titleInput}
                  onChange={(e) => setTitleInput(e.target.value)}
                  autoFocus
                  onBlur={() => {
                    if (titleInput.trim()) onRenameChat(titleInput.trim());
                    setIsEditingTitle(false);
                  }}
                  className="text-sm font-semibold px-2 py-0.5 rounded border border-indigo-400 bg-white dark:bg-zinc-900 text-zinc-900 dark:text-white"
                />
              </form>
            ) : (
              <button
                onClick={() => {
                  setTitleInput(conversation.title);
                  setIsEditingTitle(true);
                }}
                title="Click to rename chat"
                className="font-semibold text-sm text-zinc-900 dark:text-white truncate max-w-[200px] sm:max-w-sm hover:underline text-left"
              >
                {conversation.title}
              </button>
            )
          ) : (
            <span className="font-semibold text-sm text-zinc-900 dark:text-white">
              {settings.assistantName}
            </span>
          )}
        </div>

        {/* Right header actions */}
        <div className="flex items-center gap-2">
          {/* Study Mode Selector */}
          <div className="relative">
            <button
              onClick={() => setShowModeDropdown(!showModeDropdown)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium bg-zinc-100 hover:bg-zinc-200/80 dark:bg-zinc-900 dark:hover:bg-zinc-800 text-zinc-700 dark:text-zinc-300 border border-zinc-200/80 dark:border-zinc-800 transition-colors"
            >
              <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
              <span className="hidden sm:inline">{currentModeObj.name}</span>
              <span className="sm:hidden">Mode</span>
              <ChevronDown className="w-3.5 h-3.5 text-zinc-400" />
            </button>

            {showModeDropdown && (
              <>
                <div
                  onClick={() => setShowModeDropdown(false)}
                  className="fixed inset-0 z-20"
                />
                <div className="absolute right-0 mt-1 w-64 p-1.5 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl shadow-xl z-30 space-y-1">
                  <div className="px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-zinc-400">
                    Select Study Explainer Mode
                  </div>
                  {STUDY_MODES.map((m) => (
                    <button
                      key={m.id}
                      onClick={() => {
                        onUpdateStudyMode(m.id as StudyMode);
                        setShowModeDropdown(false);
                      }}
                      className={`w-full text-left px-2.5 py-2 rounded-lg text-xs transition-colors flex items-start gap-2 ${
                        currentStudyMode === m.id
                          ? 'bg-indigo-50 text-indigo-900 dark:bg-indigo-950/60 dark:text-indigo-200 font-medium'
                          : 'text-zinc-700 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800'
                      }`}
                    >
                      <div>
                        <div>{m.name}</div>
                        <div className="text-[10px] text-zinc-400 leading-tight">
                          {m.description}
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              </>
            )}
          </div>

          {/* Install App Button */}
          <PWAInstallButton />

          {/* Quick Quiz action */}
          {conversation && messages.length > 0 && (
            <button
              onClick={() => onOpenQuiz(conversation.title, messages[messages.length - 1]?.content)}
              title="Generate a 3-question quiz on this topic"
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium text-amber-700 dark:text-amber-300 bg-amber-50 hover:bg-amber-100 dark:bg-amber-950/40 dark:hover:bg-amber-950/70 border border-amber-200/80 dark:border-amber-900/60 transition-colors"
            >
              <Award className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Quiz Me</span>
            </button>
          )}

          {/* Share/Export chat */}
          {conversation && (
            <button
              onClick={() => {
                const md = exportConversationAsMarkdown(conversation);
                navigator.clipboard.writeText(md);
                alert('Conversation copied to clipboard in Markdown format!');
              }}
              title="Copy conversation markdown to clipboard"
              className="p-1.5 rounded-lg text-zinc-500 hover:text-zinc-800 dark:text-zinc-400 dark:hover:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800"
            >
              <Share2 className="w-4 h-4" />
            </button>
          )}
        </div>
      </header>

      {/* Main Conversation Scroll View */}
      <div
        ref={containerRef}
        onScroll={handleScroll}
        className="flex-1 overflow-y-auto px-4 py-6 space-y-6"
      >
        {messages.length === 0 ? (
          /* Welcome state */
          <div className="max-w-2xl mx-auto py-8 sm:py-12 space-y-8">
            <div className="text-center space-y-3">
              <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-gradient-to-tr from-indigo-600 via-violet-600 to-indigo-400 text-white shadow-lg shadow-indigo-500/25">
                <GraduationCap className="w-8 h-8" />
              </div>
              <h2 className="text-2xl font-bold tracking-tight text-zinc-900 dark:text-white">
                How can I help you learn today?
              </h2>
              <p className="text-sm text-zinc-500 dark:text-zinc-400 max-w-md mx-auto leading-relaxed">
                I am <strong>{settings.assistantName}</strong>. Ask any question in mathematics, science, coding, languages, or upload study notes for clear, step-by-step guidance.
              </p>
            </div>

            {/* Subject suggestion tiles */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              {subjectStarters.map((item, idx) => {
                const Icon = item.icon;
                return (
                  <button
                    key={idx}
                    onClick={() => onSelectPrompt(item.prompt)}
                    className="group p-3.5 rounded-2xl border border-zinc-200 dark:border-zinc-800/80 bg-zinc-50/60 dark:bg-zinc-900/40 hover:bg-zinc-100/80 dark:hover:bg-zinc-900 text-left transition-all hover:border-indigo-300 dark:hover:border-indigo-700/60 shadow-2xs hover:shadow-sm"
                  >
                    <div className="flex items-center gap-2.5 mb-1.5">
                      <div className={`p-1.5 rounded-lg bg-gradient-to-tr ${item.color} text-white shadow-2xs`}>
                        <Icon className="w-4 h-4" />
                      </div>
                      <span className="text-xs font-bold text-zinc-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
                        {item.title}
                      </span>
                    </div>
                    <p className="text-xs text-zinc-500 dark:text-zinc-400 line-clamp-2 leading-relaxed">
                      {item.prompt}
                    </p>
                  </button>
                );
              })}
            </div>
          </div>
        ) : (
          /* Message Stream */
          <div className="max-w-3xl mx-auto space-y-6">
            {messages.map((msg) => {
              const isUser = msg.role === 'user';

              return (
                <div
                  key={msg.id}
                  className={`flex gap-3 sm:gap-4 ${isUser ? 'justify-end' : 'justify-start'}`}
                >
                  {!isUser && (
                    <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-indigo-600 to-violet-600 text-white flex items-center justify-center shrink-0 shadow-xs mt-1">
                      <GraduationCap className="w-4 h-4" />
                    </div>
                  )}

                  <div
                    className={`relative max-w-[85%] sm:max-w-[80%] rounded-2xl ${
                      isUser
                        ? 'bg-indigo-600 text-white p-3.5 sm:p-4 rounded-tr-xs shadow-xs'
                        : 'bg-zinc-100/90 dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 p-4 sm:p-5 rounded-tl-xs text-zinc-900 dark:text-zinc-100 shadow-xs'
                    }`}
                  >
                    {/* Attachments preview if present */}
                    {msg.attachments && msg.attachments.length > 0 && (
                      <div className="mb-3 space-y-2">
                        {msg.attachments.map((att) => (
                          <div key={att.id}>
                            {att.type === 'image' && att.data ? (
                              <img
                                src={att.data}
                                alt={att.name}
                                className="max-h-60 rounded-xl object-contain border border-white/20 bg-black/10"
                              />
                            ) : (
                              <div
                                className={`flex items-center gap-2 p-2 rounded-lg text-xs ${
                                  isUser
                                    ? 'bg-white/10 text-white border border-white/20'
                                    : 'bg-zinc-200/70 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300'
                                }`}
                              >
                                <FileText className="w-4 h-4 shrink-0" />
                                <span className="font-medium truncate">{att.name}</span>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Content */}
                    {isUser ? (
                      <div className="text-[14.5px] leading-relaxed whitespace-pre-wrap break-words">
                        {msg.content}
                      </div>
                    ) : (
                      <div className="text-[14.5px] text-zinc-800 dark:text-zinc-200">
                        <MarkdownRenderer content={msg.content} />
                      </div>
                    )}

                    {/* Error display if message failed */}
                    {msg.error && (
                      <div className="mt-3 p-3 rounded-xl bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-900 text-xs text-red-700 dark:text-red-300 flex items-start gap-2">
                        <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                        <div className="flex-1">
                          <p className="font-medium">Generation Error</p>
                          <p>{msg.error}</p>
                          <button
                            onClick={onRegenerate}
                            className="mt-2 inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-red-600 text-white font-medium hover:bg-red-700 transition-colors"
                          >
                            <RotateCcw className="w-3 h-3" />
                            Retry
                          </button>
                        </div>
                      </div>
                    )}

                    {/* Assistant message action footer */}
                    {!isUser && !msg.error && (
                      <div className="mt-3 pt-2.5 border-t border-zinc-200/60 dark:border-zinc-800 flex items-center justify-between text-zinc-400">
                        <div className="flex items-center gap-1">
                          {/* Copy button */}
                          <button
                            onClick={() => handleCopyMessage(msg)}
                            title="Copy response"
                            className="p-1.5 rounded-lg hover:text-zinc-700 dark:hover:text-zinc-200 hover:bg-zinc-200/60 dark:hover:bg-zinc-800 transition-colors"
                          >
                            {copiedId === msg.id ? (
                              <Check className="w-3.5 h-3.5 text-emerald-500" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </button>

                          {/* Read aloud TTS button */}
                          {settings.ttsVoiceEnabled && (
                            <button
                              onClick={() => handleSpeak(msg)}
                              title={speakingId === msg.id ? 'Stop audio' : 'Read aloud'}
                              className={`p-1.5 rounded-lg transition-colors ${
                                speakingId === msg.id
                                  ? 'text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/60'
                                  : 'hover:text-zinc-700 dark:hover:text-zinc-200 hover:bg-zinc-200/60 dark:hover:bg-zinc-800'
                              }`}
                            >
                              {speakingId === msg.id ? (
                                <VolumeX className="w-3.5 h-3.5" />
                              ) : (
                                <Volume2 className="w-3.5 h-3.5" />
                              )}
                            </button>
                          )}

                          {/* Quick Quiz on this response */}
                          <button
                            onClick={() => onOpenQuiz('Review Questions', msg.content)}
                            title="Generate a quiz on this explanation"
                            className="flex items-center gap-1 px-2 py-1 rounded-lg text-xs hover:text-amber-600 dark:hover:text-amber-400 hover:bg-amber-50 dark:hover:bg-amber-950/40 transition-colors"
                          >
                            <Award className="w-3.5 h-3.5 text-amber-500" />
                            <span className="text-[11px] font-medium">Test Me</span>
                          </button>
                        </div>

                        {/* Regenerate button (only on last assistant message) */}
                        {messages[messages.length - 1]?.id === msg.id && !isStreaming && (
                          <button
                            onClick={onRegenerate}
                            title="Regenerate response"
                            className="flex items-center gap-1 px-2 py-1 rounded-lg text-xs hover:text-indigo-600 dark:hover:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/50 transition-colors"
                          >
                            <RotateCcw className="w-3 h-3" />
                            <span className="text-[11px]">Regenerate</span>
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}

            {/* Streaming indicator */}
            {isStreaming && (
              <div className="flex gap-3 sm:gap-4 items-center pl-1 text-zinc-400 dark:text-zinc-500 text-xs">
                <div className="w-7 h-7 rounded-xl bg-indigo-600 text-white flex items-center justify-center shrink-0">
                  <Sparkles className="w-3.5 h-3.5 animate-spin" />
                </div>
                <div className="flex items-center gap-1.5 font-medium">
                  <span>{settings.assistantName} is thinking & explaining</span>
                  <span className="flex gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-bounce" style={{ animationDelay: '0ms' }} />
                    <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-bounce" style={{ animationDelay: '150ms' }} />
                    <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-bounce" style={{ animationDelay: '300ms' }} />
                  </span>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>
        )}
      </div>

      {/* Floating scroll to bottom button */}
      {showScrollBottom && (
        <button
          onClick={scrollToBottom}
          className="absolute bottom-20 right-6 z-20 p-2.5 rounded-full bg-white dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 shadow-md text-zinc-600 dark:text-zinc-300 hover:text-indigo-600 dark:hover:text-indigo-400 transition-all hover:scale-105"
        >
          <ArrowDown className="w-4 h-4" />
        </button>
      )}
    </div>
  );
};
