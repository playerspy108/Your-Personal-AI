import React, { useRef, useEffect, useState } from 'react';
import {
  ArrowUp,
  Paperclip,
  Square,
  X,
  FileText,
  Image as ImageIcon,
  WifiOff,
  Sparkles,
} from 'lucide-react';
import { Attachment } from '../types';

interface ChatInputProps {
  onSendMessage: (text: string, attachments: Attachment[]) => void;
  isStreaming: boolean;
  onStopStreaming: () => void;
  isOnline: boolean;
  placeholder?: string;
  onQuickPrompt?: (promptText: string) => void;
}

export const ChatInput: React.FC<ChatInputProps> = ({
  onSendMessage,
  isStreaming,
  onStopStreaming,
  isOnline,
  placeholder = 'Ask a question, upload a problem, or paste notes to summarize...',
  onQuickPrompt,
}) => {
  const [text, setText] = useState('');
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(
        textareaRef.current.scrollHeight,
        180
      )}px`;
    }
  }, [text]);

  const handleSend = () => {
    if ((!text.trim() && attachments.length === 0) || isStreaming) return;
    onSendMessage(text.trim(), attachments);
    setText('');
    setAttachments([]);
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const processFile = (file: File) => {
    const isImage = file.type.startsWith('image/');
    const reader = new FileReader();

    if (isImage) {
      reader.onload = () => {
        const base64 = reader.result as string;
        setAttachments((prev) => [
          ...prev,
          {
            id: Math.random().toString(36).substring(2, 9),
            type: 'image',
            name: file.name,
            mimeType: file.type || 'image/png',
            size: file.size,
            data: base64,
          },
        ]);
      };
      reader.readAsDataURL(file);
    } else {
      // Treat as text / study document
      reader.onload = () => {
        const textContent = reader.result as string;
        setAttachments((prev) => [
          ...prev,
          {
            id: Math.random().toString(36).substring(2, 9),
            type: 'file',
            name: file.name,
            mimeType: file.type || 'text/plain',
            size: file.size,
            text: textContent,
          },
        ]);
      };
      reader.readAsText(file);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      Array.from(e.target.files).forEach(processFile);
    }
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const removeAttachment = (id: string) => {
    setAttachments((prev) => prev.filter((a) => a.id !== id));
  };

  const quickPrompts = [
    'Explain step-by-step',
    'Summarize into key takeaways',
    'Give a real-world example',
    'Quiz me on this concept',
    'Simplify for a beginner',
  ];

  return (
    <div className="w-full max-w-3xl mx-auto px-4 pb-4">
      {/* Offline banner warning */}
      {!isOnline && (
        <div className="mb-2.5 px-3.5 py-2 rounded-xl bg-amber-50 dark:bg-amber-950/50 border border-amber-200 dark:border-amber-900/60 flex items-center justify-between text-xs text-amber-800 dark:text-amber-300">
          <div className="flex items-center gap-2">
            <WifiOff className="w-4 h-4 shrink-0 text-amber-600" />
            <span>
              You are offline. Previously saved chats remain fully readable, but asking new AI questions requires an internet connection.
            </span>
          </div>
        </div>
      )}

      {/* Quick suggestions chips */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-none no-scrollbar text-xs">
        {quickPrompts.map((prompt, i) => (
          <button
            key={i}
            type="button"
            onClick={() => onQuickPrompt?.(prompt)}
            className="flex items-center gap-1 px-2.5 py-1 rounded-full whitespace-nowrap bg-zinc-100 hover:bg-zinc-200/80 dark:bg-zinc-800 dark:hover:bg-zinc-700/80 text-zinc-600 dark:text-zinc-300 border border-zinc-200/80 dark:border-zinc-700/60 transition-colors text-[11.5px]"
          >
            <Sparkles className="w-3 h-3 text-indigo-500" />
            <span>{prompt}</span>
          </button>
        ))}
      </div>

      {/* Main input wrapper */}
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragging(true);
        }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={(e) => {
          e.preventDefault();
          setIsDragging(false);
          if (e.dataTransfer.files) {
            Array.from(e.dataTransfer.files).forEach(processFile);
          }
        }}
        className={`relative rounded-2xl bg-white dark:bg-zinc-900 border transition-all shadow-sm ${
          isDragging
            ? 'border-indigo-500 ring-2 ring-indigo-500/30'
            : 'border-zinc-200 dark:border-zinc-800 focus-within:border-indigo-500/80 focus-within:ring-2 focus-within:ring-indigo-500/20'
        }`}
      >
        {/* Attachment preview chips */}
        {attachments.length > 0 && (
          <div className="flex flex-wrap gap-2 p-3 border-b border-zinc-100 dark:border-zinc-800">
            {attachments.map((att) => (
              <div
                key={att.id}
                className="flex items-center gap-2 px-2.5 py-1 rounded-lg bg-zinc-100 dark:bg-zinc-800 text-xs text-zinc-800 dark:text-zinc-200 border border-zinc-200 dark:border-zinc-700"
              >
                {att.type === 'image' ? (
                  <ImageIcon className="w-3.5 h-3.5 text-indigo-500" />
                ) : (
                  <FileText className="w-3.5 h-3.5 text-indigo-500" />
                )}
                <span className="max-w-[140px] truncate font-medium">{att.name}</span>
                <button
                  type="button"
                  onClick={() => removeAttachment(att.id)}
                  className="p-0.5 rounded hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Text area & controls */}
        <div className="flex items-end p-2 sm:p-2.5 gap-2">
          {/* File attach button */}
          <input
            ref={fileInputRef}
            type="file"
            multiple
            accept="image/*,.txt,.md,.py,.js,.ts,.json,.csv"
            onChange={handleFileChange}
            className="hidden"
          />
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            title="Attach image or study notes"
            className="p-2 rounded-xl text-zinc-500 hover:text-zinc-700 dark:text-zinc-400 dark:hover:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors shrink-0"
          >
            <Paperclip className="w-5 h-5" />
          </button>

          <textarea
            ref={textareaRef}
            rows={1}
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={placeholder}
            className="flex-1 max-h-48 py-2 px-1 text-sm bg-transparent text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 dark:placeholder-zinc-500 resize-none focus:outline-none leading-relaxed"
          />

          {/* Action button: Send or Stop */}
          {isStreaming ? (
            <button
              type="button"
              onClick={onStopStreaming}
              title="Stop generating"
              className="p-2 rounded-xl bg-red-600 hover:bg-red-700 text-white shrink-0 transition-transform active:scale-95 shadow-sm shadow-red-600/30"
            >
              <Square className="w-4 h-4 fill-white" />
            </button>
          ) : (
            <button
              type="button"
              onClick={handleSend}
              disabled={(!text.trim() && attachments.length === 0) || !isOnline}
              title={!isOnline ? 'Offline: Reconnect to send' : 'Send message (Enter)'}
              className="p-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 disabled:opacity-40 disabled:hover:bg-indigo-600 text-white shrink-0 transition-transform active:scale-95 shadow-sm shadow-indigo-600/30"
            >
              <ArrowUp className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      <div className="mt-1.5 flex items-center justify-between text-[11px] text-zinc-400 dark:text-zinc-500 px-1">
        <span>Enter to send, Shift + Enter for new line</span>
        <span>Supports notes, diagrams, and code</span>
      </div>
    </div>
  );
};
