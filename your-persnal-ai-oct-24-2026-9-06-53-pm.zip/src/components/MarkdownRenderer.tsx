import React, { useState } from 'react';
import { Check, Copy, Terminal } from 'lucide-react';
import { marked } from 'marked';

interface MarkdownRendererProps {
  content: string;
}

export const MarkdownRenderer: React.FC<MarkdownRendererProps> = ({ content }) => {
  // Split content by code fences (```lang ... ```) to render interactive code blocks with copy buttons
  const parts = React.useMemo(() => {
    const codeBlockRegex = /```([a-zA-Z0-9_-]*)\n([\s\S]*?)```/g;
    const segments: Array<{ type: 'markdown' | 'code'; text: string; language?: string }> = [];
    let lastIndex = 0;
    let match: RegExpExecArray | null;

    while ((match = codeBlockRegex.exec(content)) !== null) {
      if (match.index > lastIndex) {
        segments.push({
          type: 'markdown',
          text: content.substring(lastIndex, match.index),
        });
      }
      segments.push({
        type: 'code',
        language: match[1] || 'text',
        text: match[2],
      });
      lastIndex = match.index + match[0].length;
    }

    if (lastIndex < content.length) {
      segments.push({
        type: 'markdown',
        text: content.substring(lastIndex),
      });
    }

    return segments;
  }, [content]);

  return (
    <div className="space-y-3 leading-relaxed text-[15px] max-w-none">
      {parts.map((segment, idx) => {
        if (segment.type === 'code') {
          return (
            <CodeBlock
              key={idx}
              language={segment.language || 'code'}
              code={segment.text}
            />
          );
        }

        // Render standard markdown segment
        const html = marked.parse(segment.text, {
          gfm: true,
          breaks: true,
        }) as string;

        return (
          <div
            key={idx}
            className="prose-content"
            dangerouslySetInnerHTML={{ __html: html }}
          />
        );
      })}
    </div>
  );
};

interface CodeBlockProps {
  language: string;
  code: string;
}

const CodeBlock: React.FC<CodeBlockProps> = ({ language, code }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy code:', err);
    }
  };

  return (
    <div className="my-3 overflow-hidden rounded-xl border border-zinc-200 dark:border-zinc-800 bg-zinc-900 text-zinc-100 shadow-sm">
      <div className="flex items-center justify-between px-4 py-2 border-b border-zinc-800 bg-zinc-950/70 text-xs font-mono text-zinc-400">
        <span className="flex items-center gap-1.5 font-medium uppercase tracking-wider text-zinc-300">
          <Terminal className="w-3.5 h-3.5 text-indigo-400" />
          {language || 'text'}
        </span>
        <button
          onClick={handleCopy}
          aria-label="Copy code"
          className="flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium text-zinc-300 hover:text-white bg-zinc-800/80 hover:bg-zinc-800 transition-colors"
        >
          {copied ? (
            <>
              <Check className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-emerald-400">Copied!</span>
            </>
          ) : (
            <>
              <Copy className="w-3.5 h-3.5" />
              <span>Copy</span>
            </>
          )}
        </button>
      </div>
      <div className="p-4 overflow-x-auto font-mono text-[13.5px] leading-relaxed text-zinc-200 selection:bg-indigo-500/30">
        <pre className="m-0 p-0">
          <code>{code}</code>
        </pre>
      </div>
    </div>
  );
};
