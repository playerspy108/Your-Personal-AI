import { Conversation, UserSettings } from '../types';

const CONVERSATIONS_KEY = 'your_personal_ai_conversations_v1';
const SETTINGS_KEY = 'your_personal_ai_settings_v1';

export const DEFAULT_SETTINGS: UserSettings = {
  assistantName: 'Your Personal AI',
  language: 'English',
  studyMode: 'step-by-step',
  detailLevel: 'detailed',
  theme: 'system',
  ttsVoiceEnabled: true,
};

export const AVAILABLE_LANGUAGES = [
  { code: 'English', label: 'English' },
  { code: 'Spanish', label: 'Español (Spanish)' },
  { code: 'French', label: 'Français (French)' },
  { code: 'German', label: 'Deutsch (German)' },
  { code: 'Hindi', label: 'हिन्दी (Hindi)' },
  { code: 'Japanese', label: '日本語 (Japanese)' },
  { code: 'Chinese (Simplified)', label: '简体中文 (Chinese)' },
  { code: 'Portuguese', label: 'Português (Portuguese)' },
  { code: 'Arabic', label: 'العربية (Arabic)' },
  { code: 'Russian', label: 'Русский (Russian)' },
  { code: 'Italian', label: 'Italiano (Italian)' },
  { code: 'Korean', label: '한국어 (Korean)' },
];

export const STUDY_MODES = [
  {
    id: 'step-by-step',
    name: 'Step-by-Step Explainer',
    description: 'Breaks complex math, science, and reasoning problems into sequential parts.',
    icon: 'ListOrdered',
  },
  {
    id: 'socratic',
    name: 'Socratic Tutor',
    description: 'Guides you with hints and questions so you discover the answer yourself.',
    icon: 'HelpCircle',
  },
  {
    id: 'exam-prep',
    name: 'Exam & Test Prep',
    description: 'Highlights high-yield formulas, common pitfalls, and memory tricks.',
    icon: 'GraduationCap',
  },
  {
    id: 'code-mentor',
    name: 'Code & Algorithm Mentor',
    description: 'Explains programming syntax, debugs logic, and analyzes complexity.',
    icon: 'Code2',
  },
  {
    id: 'quick-summary',
    name: 'Notes & Document Summarizer',
    description: 'Condenses textbook chapters, study notes, and research into key bullets.',
    icon: 'FileText',
  },
  {
    id: 'language-tutor',
    name: 'Language & Grammar Coach',
    description: 'Grammar breakdowns, vocabulary drills, and natural conversational practice.',
    icon: 'Languages',
  },
] as const;

export function loadSettings(): UserSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed.assistantName === 'Your Persnal AI') {
        parsed.assistantName = 'Your Personal AI';
      }
      return { ...DEFAULT_SETTINGS, ...parsed };
    }
  } catch (e) {
    console.warn('Failed to load settings from localStorage:', e);
  }
  return DEFAULT_SETTINGS;
}

export function saveSettings(settings: UserSettings): void {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch (e) {
    console.error('Failed to save settings to localStorage:', e);
  }
}

export function loadConversations(): Conversation[] {
  try {
    const raw = localStorage.getItem(CONVERSATIONS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        return parsed;
      }
    }
  } catch (e) {
    console.warn('Failed to load conversations from localStorage:', e);
  }
  return [];
}

export function saveConversations(conversations: Conversation[]): void {
  try {
    localStorage.setItem(CONVERSATIONS_KEY, JSON.stringify(conversations));
  } catch (e) {
    console.error('Failed to save conversations to localStorage:', e);
  }
}

export function exportConversationAsMarkdown(conv: Conversation): string {
  const dateStr = new Date(conv.createdAt).toLocaleString();
  let md = `# ${conv.title}\n*Saved from Your Personal AI on ${dateStr}*\n\n---\n\n`;

  conv.messages.forEach((msg) => {
    const sender = msg.role === 'user' ? '👤 You' : '🤖 Assistant';
    const time = new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    md += `### ${sender} (${time})\n\n`;

    if (msg.attachments && msg.attachments.length > 0) {
      md += `*Attached: ${msg.attachments.map((a) => a.name).join(', ')}*\n\n`;
    }

    md += `${msg.content}\n\n---\n\n`;
  });

  return md;
}

export function exportAllDataAsJSON(conversations: Conversation[], settings: UserSettings): string {
  return JSON.stringify(
    {
      version: 1,
      appName: 'Your Personal AI',
      exportedAt: new Date().toISOString(),
      settings,
      conversations,
    },
    null,
    2
  );
}
