import React, { useState, useEffect, useRef, useTransition } from 'react';
import { Conversation, Message, UserSettings, Attachment, StudyMode, ThemeMode } from './types';
import {
  loadConversations,
  saveConversations,
  loadSettings,
  saveSettings,
  DEFAULT_SETTINGS,
} from './utils/storage';
import { Sidebar } from './components/Sidebar';
import { ChatArea } from './components/ChatArea';
import { ChatInput } from './components/ChatInput';
import { SettingsModal } from './components/SettingsModal';
import { QuizModal } from './components/QuizModal';

export default function App() {
  const [conversations, setConversations] = useState<Conversation[]>(() => loadConversations());
  const [currentId, setCurrentId] = useState<string | null>(() => {
    const list = loadConversations();
    return list.length > 0 ? list[0].id : null;
  });
  const [settings, setSettings] = useState<UserSettings>(() => loadSettings());
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [quizState, setQuizState] = useState<{ isOpen: boolean; topic: string; context?: string }>({
    isOpen: false,
    topic: '',
  });
  const [isStreaming, setIsStreaming] = useState(false);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const abortControllerRef = useRef<AbortController | null>(null);

  // Monitor online / offline state
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Periodically verify server health
    const interval = setInterval(async () => {
      try {
        const res = await fetch('/api/health');
        if (res.ok) {
          setIsOnline(true);
        }
      } catch {
        // Can be offline or server starting
      }
    }, 30000);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      clearInterval(interval);
    };
  }, []);

  // Sync theme to DOM
  useEffect(() => {
    const root = document.documentElement;
    const isDark =
      settings.theme === 'dark' ||
      (settings.theme === 'system' &&
        window.matchMedia('(prefers-color-scheme: dark)').matches);

    if (isDark) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [settings.theme]);

  // Persist conversations
  useEffect(() => {
    saveConversations(conversations);
  }, [conversations]);

  // Persist settings
  useEffect(() => {
    saveSettings(settings);
  }, [settings]);

  // Keyboard shortcut for New Chat (Cmd+K / Ctrl+K)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        handleNewChat();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const currentConversation = conversations.find((c) => c.id === currentId) || null;

  const handleNewChat = () => {
    if (isStreaming) {
      handleStopStreaming();
    }
    const newConv: Conversation = {
      id: Math.random().toString(36).substring(2, 10),
      title: 'New Study Chat',
      createdAt: Date.now(),
      updatedAt: Date.now(),
      messages: [],
      studyMode: settings.studyMode,
    };
    setConversations((prev) => [newConv, ...prev]);
    setCurrentId(newConv.id);
  };

  const handleSelectConversation = (id: string) => {
    if (isStreaming) {
      handleStopStreaming();
    }
    setCurrentId(id);
  };

  const handleDeleteConversation = (id: string) => {
    setConversations((prev) => {
      const updated = prev.filter((c) => c.id !== id);
      if (currentId === id) {
        setCurrentId(updated.length > 0 ? updated[0].id : null);
      }
      return updated;
    });
  };

  const handleRenameConversation = (id: string, newTitle: string) => {
    setConversations((prev) =>
      prev.map((c) => (c.id === id ? { ...c, title: newTitle, updatedAt: Date.now() } : c))
    );
  };

  const handleTogglePin = (id: string) => {
    setConversations((prev) =>
      prev.map((c) => (c.id === id ? { ...c, pinned: !c.pinned } : c))
    );
  };

  const handleToggleTheme = () => {
    setSettings((prev) => {
      const next: ThemeMode =
        prev.theme === 'light' ? 'dark' : prev.theme === 'dark' ? 'system' : 'light';
      return { ...prev, theme: next };
    });
  };

  const handleStopStreaming = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    setIsStreaming(false);
  };

  const handleSendMessage = async (text: string, attachments: Attachment[] = []) => {
    if (!text && attachments.length === 0) return;

    if (!isOnline) {
      alert('You are currently offline. New AI answers require an internet connection.');
      return;
    }

    let targetConv = currentConversation;
    let convId = currentId;

    // Create a new conversation if none exists
    if (!targetConv || !convId) {
      const title = text.slice(0, 32) || 'Study Session';
      targetConv = {
        id: Math.random().toString(36).substring(2, 10),
        title,
        createdAt: Date.now(),
        updatedAt: Date.now(),
        messages: [],
        studyMode: settings.studyMode,
      };
      convId = targetConv.id;
      setConversations((prev) => [targetConv!, ...prev]);
      setCurrentId(convId);
    } else if (targetConv.messages.length === 0 && text) {
      // Auto-title conversation from first query
      const newTitle = text.slice(0, 36) + (text.length > 36 ? '...' : '');
      targetConv = { ...targetConv, title: newTitle };
      setConversations((prev) =>
        prev.map((c) => (c.id === convId ? { ...c, title: newTitle } : c))
      );
    }

    const userMessage: Message = {
      id: Math.random().toString(36).substring(2, 10),
      role: 'user',
      content: text,
      timestamp: Date.now(),
      attachments: attachments.length > 0 ? attachments : undefined,
    };

    const assistantMessageId = Math.random().toString(36).substring(2, 10);
    const initialAssistantMessage: Message = {
      id: assistantMessageId,
      role: 'assistant',
      content: '',
      timestamp: Date.now(),
      isStreaming: true,
    };

    const updatedMessages = [...targetConv.messages, userMessage];

    // Optimistically update conversation
    setConversations((prev) =>
      prev.map((c) =>
        c.id === convId
          ? {
              ...c,
              updatedAt: Date.now(),
              messages: [...updatedMessages, initialAssistantMessage],
            }
          : c
      )
    );

    setIsStreaming(true);
    abortControllerRef.current = new AbortController();

    try {
      // Call server streaming endpoint
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        signal: abortControllerRef.current.signal,
        body: JSON.stringify({
          messages: updatedMessages.map((m) => ({
            role: m.role,
            content: m.content,
            attachments: m.attachments,
          })),
          settings: {
            assistantName: settings.assistantName,
            language: settings.language,
            studyMode: targetConv.studyMode || settings.studyMode,
            detailLevel: settings.detailLevel,
          },
          stream: true,
        }),
      });

      if (!response.ok) {
        const errorJson = await response.json().catch(() => ({}));
        throw new Error(errorJson.error || `Server returned ${response.status}`);
      }

      const reader = response.body?.getReader();
      if (!reader) throw new Error('No readable stream available from server.');

      const decoder = new TextDecoder();
      let accumulatedText = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value, { stream: true });
        const lines = chunk.split('\n');

        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed.startsWith('data:')) continue;
          const dataStr = trimmed.slice(5).trim();

          if (dataStr === '[DONE]') {
            break;
          }

          try {
            const parsed = JSON.parse(dataStr);
            if (parsed.error) {
              throw new Error(parsed.error);
            }
            if (parsed.text) {
              accumulatedText += parsed.text;
              setConversations((prev) =>
                prev.map((c) => {
                  if (c.id !== convId) return c;
                  return {
                    ...c,
                    messages: c.messages.map((m) =>
                      m.id === assistantMessageId
                        ? { ...m, content: accumulatedText, isStreaming: true }
                        : m
                    ),
                  };
                })
              );
            }
          } catch (e: any) {
            if (dataStr !== '[DONE]') {
              console.warn('Error parsing SSE data chunk:', e);
            }
          }
        }
      }

      // Finalize assistant message
      setConversations((prev) =>
        prev.map((c) => {
          if (c.id !== convId) return c;
          return {
            ...c,
            updatedAt: Date.now(),
            messages: c.messages.map((m) =>
              m.id === assistantMessageId
                ? { ...m, content: accumulatedText, isStreaming: false }
                : m
            ),
          };
        })
      );
    } catch (err: any) {
      if (err.name === 'AbortError') {
        console.log('Stream generation aborted by user.');
      } else {
        console.error('Chat generation error:', err);
        const errMsg = err.message || 'Failed to complete study answer.';
        setConversations((prev) =>
          prev.map((c) => {
            if (c.id !== convId) return c;
            return {
              ...c,
              messages: c.messages.map((m) =>
                m.id === assistantMessageId
                  ? { ...m, error: errMsg, isStreaming: false }
                  : m
              ),
            };
          })
        );
      }
    } finally {
      setIsStreaming(false);
      abortControllerRef.current = null;
    }
  };

  const handleRegenerate = () => {
    if (!currentConversation || currentConversation.messages.length === 0) return;
    const msgs = [...currentConversation.messages];
    // Find last user message
    let lastUserIndex = -1;
    for (let i = msgs.length - 1; i >= 0; i--) {
      if (msgs[i].role === 'user') {
        lastUserIndex = i;
        break;
      }
    }

    if (lastUserIndex === -1) return;
    const lastUserMessage = msgs[lastUserIndex];

    // Remove everything after and including the last assistant message
    const trimmedMessages = msgs.slice(0, lastUserIndex);
    setConversations((prev) =>
      prev.map((c) => (c.id === currentId ? { ...c, messages: trimmedMessages } : c))
    );

    handleSendMessage(lastUserMessage.content, lastUserMessage.attachments || []);
  };

  const handleUpdateStudyMode = (mode: StudyMode) => {
    if (!currentId) return;
    setConversations((prev) =>
      prev.map((c) => (c.id === currentId ? { ...c, studyMode: mode } : c))
    );
  };

  const handleClearAllHistory = () => {
    setConversations([]);
    setCurrentId(null);
    localStorage.removeItem('your_personal_ai_conversations_v1');
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-zinc-100 dark:bg-zinc-950 text-zinc-900 dark:text-zinc-100 font-sans antialiased">
      {/* Sidebar for new chats and past conversations */}
      <Sidebar
        conversations={conversations}
        currentConversationId={currentId}
        onSelectConversation={handleSelectConversation}
        onNewChat={handleNewChat}
        onDeleteConversation={handleDeleteConversation}
        onRenameConversation={handleRenameConversation}
        onTogglePin={handleTogglePin}
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
        onOpenSettings={() => setIsSettingsOpen(true)}
        isOnline={isOnline}
        theme={settings.theme}
        onToggleTheme={handleToggleTheme}
        assistantName={settings.assistantName}
      />

      {/* Main Study Chat Area */}
      <main className="flex-1 flex flex-col h-full min-w-0 bg-white dark:bg-zinc-950 relative">
        <ChatArea
          conversation={currentConversation}
          settings={settings}
          onOpenSidebar={() => setIsSidebarOpen(true)}
          onSelectPrompt={(prompt) => handleSendMessage(prompt)}
          onRegenerate={handleRegenerate}
          onOpenQuiz={(topic, context) =>
            setQuizState({ isOpen: true, topic, context })
          }
          onUpdateStudyMode={handleUpdateStudyMode}
          isStreaming={isStreaming}
          onRenameChat={(title) => {
            if (currentId) handleRenameConversation(currentId, title);
          }}
        />

        {/* Bottom Input Area */}
        <ChatInput
          onSendMessage={handleSendMessage}
          isStreaming={isStreaming}
          onStopStreaming={handleStopStreaming}
          isOnline={isOnline}
          placeholder={`Ask ${settings.assistantName} a math, science, language, or coding question...`}
          onQuickPrompt={(prompt) => handleSendMessage(prompt)}
        />
      </main>

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onSaveSettings={(newSettings) => setSettings(newSettings)}
        conversations={conversations}
        onClearAllHistory={handleClearAllHistory}
      />

      {/* Interactive Quiz Modal */}
      <QuizModal
        isOpen={quizState.isOpen}
        onClose={() => setQuizState({ ...quizState, isOpen: false })}
        topicTitle={quizState.topic}
        topicContext={quizState.context}
        language={settings.language}
      />
    </div>
  );
}
